/* tslint:disable */

export interface NodeAPHP {

  idNode?: number;

  floor: string;

  name: string;
}
