/* tslint:disable */

export interface Node {

  idNode?: number;

  floor: string;

  name: string;
}
