/* tslint:disable */

export interface Specialization {

  idSpecialization?: number;

  generalName: string;

  staffName: string;
}
