/* tslint:disable */

export interface UserAccount {

  idAccount?: number;

  username: string;

  password: string;

  type: string;
}
