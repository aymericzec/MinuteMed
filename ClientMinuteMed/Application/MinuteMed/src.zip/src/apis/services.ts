export { AuthenticationRESTEndpointService } from './services/authentication-restendpoint.service';
export { ArborescenceRESTEndpointService } from './services/arborescence-restendpoint.service';
export { MedicalRecordsRESTEndpointService } from './services/medical-records-restendpoint.service';
export { SpecializationsRESTEndpointService } from './services/specializations-restendpoint.service';
export { StaffRESTEndpointService } from './services/staff-restendpoint.service';
