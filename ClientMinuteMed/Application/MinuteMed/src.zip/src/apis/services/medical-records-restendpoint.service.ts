/* tslint:disable */
import { Injectable } from '@angular/core';
import {
  HttpClient, HttpRequest, HttpResponse, 
  HttpHeaders, HttpParams } from '@angular/common/http';
import { BaseService } from '../base-service';
import { ApiConfiguration } from '../api-configuration';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';
import { filter } from 'rxjs/operators/filter';

import { MedicalRecord } from '../models/medical-record';
import { Diagnostic } from '../models/diagnostic';
import { Dosage } from '../models/dosage';
import { Exam } from '../models/exam';
import { Prescription } from '../models/prescription';

@Injectable()
export class MedicalRecordsRESTEndpointService extends BaseService {
  constructor(
    config: ApiConfiguration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * @param Authorization undefined
   * @return successful operation
   */
   getAllMedicalRecordResponse(Authorization?: string): Observable<HttpResponse<MedicalRecord>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    if (Authorization != null) __headers = __headers.set("Authorization", Authorization.toString());
    let req = new HttpRequest<any>(
      "GET",
      this.rootUrl + `/records`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: MedicalRecord = null;
        _body = _resp.body as MedicalRecord
        return _resp.clone({body: _body}) as HttpResponse<MedicalRecord>;
      })
    );
  }

  /**
   * @param Authorization undefined
   * @return successful operation
   */
   getAllMedicalRecord(Authorization?: string): Observable<MedicalRecord> {
    return this.getAllMedicalRecordResponse(Authorization).pipe(
      map(_r => _r.body)
    );
  }

  createMedicalRecordResponse(): Observable<HttpResponse<void>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      "POST",
      this.rootUrl + `/records`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: void = null;
        
        return _resp.clone({body: _body}) as HttpResponse<void>;
      })
    );
  }

  createMedicalRecord(): Observable<void> {
    return this.createMedicalRecordResponse().pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param idRecord undefined
   * @return successful operation
   */
   getMedicalRecordResponse(idRecord: number): Observable<HttpResponse<MedicalRecord>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      "GET",
      this.rootUrl + `/records/${idRecord}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: MedicalRecord = null;
        _body = _resp.body as MedicalRecord
        return _resp.clone({body: _body}) as HttpResponse<MedicalRecord>;
      })
    );
  }

  /**
   * @param idRecord undefined
   * @return successful operation
   */
   getMedicalRecord(idRecord: number): Observable<MedicalRecord> {
    return this.getMedicalRecordResponse(idRecord).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param idRecord undefined
   */
   deleteMedicalRecordResponse(idRecord: number): Observable<HttpResponse<void>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      "DELETE",
      this.rootUrl + `/records/${idRecord}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: void = null;
        
        return _resp.clone({body: _body}) as HttpResponse<void>;
      })
    );
  }

  /**
   * @param idRecord undefined
   */
   deleteMedicalRecord(idRecord: number): Observable<void> {
    return this.deleteMedicalRecordResponse(idRecord).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param idRecord undefined
   * @return successful operation
   */
   getDiagnosticsResponse(idRecord: number): Observable<HttpResponse<Diagnostic[]>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      "GET",
      this.rootUrl + `/records/${idRecord}/diagnostics`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: Diagnostic[] = null;
        _body = _resp.body as Diagnostic[]
        return _resp.clone({body: _body}) as HttpResponse<Diagnostic[]>;
      })
    );
  }

  /**
   * @param idRecord undefined
   * @return successful operation
   */
   getDiagnostics(idRecord: number): Observable<Diagnostic[]> {
    return this.getDiagnosticsResponse(idRecord).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param idRecord undefined
   */
   createDiagnosticResponse(idRecord: number): Observable<HttpResponse<void>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      "POST",
      this.rootUrl + `/records/${idRecord}/diagnostics`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: void = null;
        
        return _resp.clone({body: _body}) as HttpResponse<void>;
      })
    );
  }

  /**
   * @param idRecord undefined
   */
   createDiagnostic(idRecord: number): Observable<void> {
    return this.createDiagnosticResponse(idRecord).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.GetDiagnosticParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idDiagnostic`: 
   *
   * @return successful operation
   */
   getDiagnosticResponse(params: MedicalRecordsRESTEndpointService.GetDiagnosticParams): Observable<HttpResponse<Diagnostic>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    let req = new HttpRequest<any>(
      "GET",
      this.rootUrl + `/records/${params.idRecord}/diagnostics/${params.idDiagnostic}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: Diagnostic = null;
        _body = _resp.body as Diagnostic
        return _resp.clone({body: _body}) as HttpResponse<Diagnostic>;
      })
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.GetDiagnosticParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idDiagnostic`: 
   *
   * @return successful operation
   */
   getDiagnostic(params: MedicalRecordsRESTEndpointService.GetDiagnosticParams): Observable<Diagnostic> {
    return this.getDiagnosticResponse(params).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.DeleteDiagnosticParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idDiagnostic`:
   */
   deleteDiagnosticResponse(params: MedicalRecordsRESTEndpointService.DeleteDiagnosticParams): Observable<HttpResponse<void>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    let req = new HttpRequest<any>(
      "DELETE",
      this.rootUrl + `/records/${params.idRecord}/diagnostics/${params.idDiagnostic}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: void = null;
        
        return _resp.clone({body: _body}) as HttpResponse<void>;
      })
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.DeleteDiagnosticParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idDiagnostic`:
   */
   deleteDiagnostic(params: MedicalRecordsRESTEndpointService.DeleteDiagnosticParams): Observable<void> {
    return this.deleteDiagnosticResponse(params).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param idRecord undefined
   * @return successful operation
   */
   getAllDosagesResponse(idRecord: number): Observable<HttpResponse<Dosage[]>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      "GET",
      this.rootUrl + `/records/${idRecord}/dosages`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: Dosage[] = null;
        _body = _resp.body as Dosage[]
        return _resp.clone({body: _body}) as HttpResponse<Dosage[]>;
      })
    );
  }

  /**
   * @param idRecord undefined
   * @return successful operation
   */
   getAllDosages(idRecord: number): Observable<Dosage[]> {
    return this.getAllDosagesResponse(idRecord).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param idRecord undefined
   */
   createDosageResponse(idRecord: number): Observable<HttpResponse<void>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      "POST",
      this.rootUrl + `/records/${idRecord}/dosages`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: void = null;
        
        return _resp.clone({body: _body}) as HttpResponse<void>;
      })
    );
  }

  /**
   * @param idRecord undefined
   */
   createDosage(idRecord: number): Observable<void> {
    return this.createDosageResponse(idRecord).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.GetDosageParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idDosage`: 
   *
   * @return successful operation
   */
   getDosageResponse(params: MedicalRecordsRESTEndpointService.GetDosageParams): Observable<HttpResponse<Dosage>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    let req = new HttpRequest<any>(
      "GET",
      this.rootUrl + `/records/${params.idRecord}/dosages/${params.idDosage}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: Dosage = null;
        _body = _resp.body as Dosage
        return _resp.clone({body: _body}) as HttpResponse<Dosage>;
      })
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.GetDosageParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idDosage`: 
   *
   * @return successful operation
   */
   getDosage(params: MedicalRecordsRESTEndpointService.GetDosageParams): Observable<Dosage> {
    return this.getDosageResponse(params).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.DeleteDosageParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idDosage`:
   */
   deleteDosageResponse(params: MedicalRecordsRESTEndpointService.DeleteDosageParams): Observable<HttpResponse<void>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    let req = new HttpRequest<any>(
      "DELETE",
      this.rootUrl + `/records/${params.idRecord}/dosages/${params.idDosage}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: void = null;
        
        return _resp.clone({body: _body}) as HttpResponse<void>;
      })
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.DeleteDosageParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idDosage`:
   */
   deleteDosage(params: MedicalRecordsRESTEndpointService.DeleteDosageParams): Observable<void> {
    return this.deleteDosageResponse(params).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param idRecord undefined
   * @return successful operation
   */
   getExamsResponse(idRecord: number): Observable<HttpResponse<Exam[]>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      "GET",
      this.rootUrl + `/records/${idRecord}/exams`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: Exam[] = null;
        _body = _resp.body as Exam[]
        return _resp.clone({body: _body}) as HttpResponse<Exam[]>;
      })
    );
  }

  /**
   * @param idRecord undefined
   * @return successful operation
   */
   getExams(idRecord: number): Observable<Exam[]> {
    return this.getExamsResponse(idRecord).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param idRecord undefined
   */
   createExamResponse(idRecord: number): Observable<HttpResponse<void>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      "POST",
      this.rootUrl + `/records/${idRecord}/exams`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: void = null;
        
        return _resp.clone({body: _body}) as HttpResponse<void>;
      })
    );
  }

  /**
   * @param idRecord undefined
   */
   createExam(idRecord: number): Observable<void> {
    return this.createExamResponse(idRecord).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.GetExamParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idExam`: 
   *
   * @return successful operation
   */
   getExamResponse(params: MedicalRecordsRESTEndpointService.GetExamParams): Observable<HttpResponse<Exam>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    let req = new HttpRequest<any>(
      "GET",
      this.rootUrl + `/records/${params.idRecord}/exams/${params.idExam}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: Exam = null;
        _body = _resp.body as Exam
        return _resp.clone({body: _body}) as HttpResponse<Exam>;
      })
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.GetExamParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idExam`: 
   *
   * @return successful operation
   */
   getExam(params: MedicalRecordsRESTEndpointService.GetExamParams): Observable<Exam> {
    return this.getExamResponse(params).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.DeleteExamParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idExam`:
   */
   deleteExamResponse(params: MedicalRecordsRESTEndpointService.DeleteExamParams): Observable<HttpResponse<void>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    let req = new HttpRequest<any>(
      "DELETE",
      this.rootUrl + `/records/${params.idRecord}/exams/${params.idExam}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: void = null;
        
        return _resp.clone({body: _body}) as HttpResponse<void>;
      })
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.DeleteExamParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idExam`:
   */
   deleteExam(params: MedicalRecordsRESTEndpointService.DeleteExamParams): Observable<void> {
    return this.deleteExamResponse(params).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param idRecord undefined
   * @return successful operation
   */
   getPrescriptionsResponse(idRecord: number): Observable<HttpResponse<Prescription[]>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      "GET",
      this.rootUrl + `/records/${idRecord}/prescriptions`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: Prescription[] = null;
        _body = _resp.body as Prescription[]
        return _resp.clone({body: _body}) as HttpResponse<Prescription[]>;
      })
    );
  }

  /**
   * @param idRecord undefined
   * @return successful operation
   */
   getPrescriptions(idRecord: number): Observable<Prescription[]> {
    return this.getPrescriptionsResponse(idRecord).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param idRecord undefined
   */
   createPrescriptionResponse(idRecord: number): Observable<HttpResponse<void>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      "POST",
      this.rootUrl + `/records/${idRecord}/prescriptions`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: void = null;
        
        return _resp.clone({body: _body}) as HttpResponse<void>;
      })
    );
  }

  /**
   * @param idRecord undefined
   */
   createPrescription(idRecord: number): Observable<void> {
    return this.createPrescriptionResponse(idRecord).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.GetPrescriptionParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idPrescription`: 
   *
   * @return successful operation
   */
   getPrescriptionResponse(params: MedicalRecordsRESTEndpointService.GetPrescriptionParams): Observable<HttpResponse<Prescription>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    let req = new HttpRequest<any>(
      "GET",
      this.rootUrl + `/records/${params.idRecord}/prescriptions/${params.idPrescription}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: Prescription = null;
        _body = _resp.body as Prescription
        return _resp.clone({body: _body}) as HttpResponse<Prescription>;
      })
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.GetPrescriptionParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idPrescription`: 
   *
   * @return successful operation
   */
   getPrescription(params: MedicalRecordsRESTEndpointService.GetPrescriptionParams): Observable<Prescription> {
    return this.getPrescriptionResponse(params).pipe(
      map(_r => _r.body)
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.DeletePrescriptionParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idPrescription`:
   */
   deletePrescriptionResponse(params: MedicalRecordsRESTEndpointService.DeletePrescriptionParams): Observable<HttpResponse<void>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    let req = new HttpRequest<any>(
      "DELETE",
      this.rootUrl + `/records/${params.idRecord}/prescriptions/${params.idPrescription}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      filter(_r => _r instanceof HttpResponse),
      map(_r => {
        let _resp = _r as HttpResponse<any>;
        let _body: void = null;
        
        return _resp.clone({body: _body}) as HttpResponse<void>;
      })
    );
  }

  /**
   * @param params The `MedicalRecordsRESTEndpointService.DeletePrescriptionParams` containing the following parameters:
   *
   * - `idRecord`: 
   *
   * - `idPrescription`:
   */
   deletePrescription(params: MedicalRecordsRESTEndpointService.DeletePrescriptionParams): Observable<void> {
    return this.deletePrescriptionResponse(params).pipe(
      map(_r => _r.body)
    );
  }
}

export module MedicalRecordsRESTEndpointService {

  /**
   * Parameters for getDiagnostic
   */
   export interface GetDiagnosticParams {

    idRecord: number;

    idDiagnostic: number;
  }

  /**
   * Parameters for deleteDiagnostic
   */
   export interface DeleteDiagnosticParams {

    idRecord: number;

    idDiagnostic: number;
  }

  /**
   * Parameters for getDosage
   */
   export interface GetDosageParams {

    idRecord: number;

    idDosage: number;
  }

  /**
   * Parameters for deleteDosage
   */
   export interface DeleteDosageParams {

    idRecord: number;

    idDosage: number;
  }

  /**
   * Parameters for getExam
   */
   export interface GetExamParams {

    idRecord: number;

    idExam: number;
  }

  /**
   * Parameters for deleteExam
   */
   export interface DeleteExamParams {

    idRecord: number;

    idExam: number;
  }

  /**
   * Parameters for getPrescription
   */
   export interface GetPrescriptionParams {

    idRecord: number;

    idPrescription: number;
  }

  /**
   * Parameters for deletePrescription
   */
   export interface DeletePrescriptionParams {

    idRecord: number;

    idPrescription: number;
  }
}
