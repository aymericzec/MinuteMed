import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consultdiagnostic',
  templateUrl: './consultdiagnostic.component.html',
  styleUrls: ['./consultdiagnostic.component.css']
})
export class ConsultdiagnosticComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
