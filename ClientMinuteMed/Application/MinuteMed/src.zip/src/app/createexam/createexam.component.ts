import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createexam',
  templateUrl: './createexam.component.html',
  styleUrls: ['./createexam.component.css']
})
export class CreateexamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
