import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consultexam',
  templateUrl: './consultexam.component.html',
  styleUrls: ['./consultexam.component.css']
})
export class ConsultexamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
