import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consultprescription',
  templateUrl: './consultprescription.component.html',
  styleUrls: ['./consultprescription.component.css']
})
export class ConsultprescriptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
