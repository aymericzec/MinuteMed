import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consultposologie',
  templateUrl: './consultposologie.component.html',
  styleUrls: ['./consultposologie.component.css']
})
export class ConsultposologieComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
