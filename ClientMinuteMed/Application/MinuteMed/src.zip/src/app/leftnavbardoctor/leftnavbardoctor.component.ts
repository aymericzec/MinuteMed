import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leftnavbardoctor',
  templateUrl: './leftnavbardoctor.component.html',
  styleUrls: ['./leftnavbardoctor.component.css']
})
export class LeftnavbardoctorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
