import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-creatediagnostic',
  templateUrl: './creatediagnostic.component.html',
  styleUrls: ['./creatediagnostic.component.css']
})
export class CreatediagnosticComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
