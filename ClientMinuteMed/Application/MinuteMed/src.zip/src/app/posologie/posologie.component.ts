import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-posologie',
  templateUrl: './posologie.component.html',
  styleUrls: ['./posologie.component.css']
})
export class PosologieComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
