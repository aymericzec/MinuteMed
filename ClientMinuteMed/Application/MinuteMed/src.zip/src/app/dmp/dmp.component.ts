import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dmp',
  templateUrl: './dmp.component.html',
  styleUrls: ['./dmp.component.css']
})
export class DmpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
